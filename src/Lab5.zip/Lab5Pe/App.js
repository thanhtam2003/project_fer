import React, { useReducer, useState } from "react";
import {
    BrowserRouter as Router,
    Route,
    Link,
    Routes,
    Outlet,
} from "react-router-dom";
import { Navbar, Nav, Row, Col, Carousel, Card, Button, Form, Container, InputGroup } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import '@fortawesome/fontawesome-free/css/all.min.css';
import 'bootstrap/dist/js/bootstrap.bundle';
import { ChatRoom } from './chat';

function ChatRoomPage() {

    return (
        <Container>
            <Col >
                <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                    <Form.Label><span style={{ color: 'blue', fontWeight: 'bold' }}>Home</span> / ChatRoom</Form.Label>
                    <Form.Control as="textarea" rows={3} />
                </Form.Group>
            </Col>


        </Container>
    );
}

function App() {
    return (
        <Container>
            <Row>
                <Col>
                    <Container>
                        <Row>
                            <Col>
                                <Router>
                                    <Navbar collapseOnSelect expand="lg" style={{ backgroundColor: 'darkred' }}>
                                        <Container>
                                            <img src="./images/logo_fpt.jpg" style={{ borderRadius: '50%', height: '60px', width: '100px' }} />
                                            <Navbar.Toggle aria-controls="responsive-navbar-nav" />
                                            <Navbar.Collapse id="responsive-navbar-nav">
                                                <Nav className="me-auto">
                                                </Nav>
                                                <Nav>
                                                    <Nav.Link as={Link} to="/" style={{ color: '#fff', marginRight: '15px' }}>
                                                        Home
                                                    </Nav.Link>
                                                    <Nav.Link as={Link} to="/chat-room" style={{ color: '#fff' }}>
                                                        Chat Room
                                                    </Nav.Link>
                                                </Nav>
                                            </Navbar.Collapse>
                                        </Container>
                                    </Navbar>
                                    <Carousel>
                                        <Carousel.Item>
                                            <img
                                                className="d-block w-100"
                                                src="./images/slider1.webp"
                                                alt="First slide"
                                                style={{ objectFit: 'cover' }}
                                            />
                                        </Carousel.Item>
                                        <Carousel.Item>
                                            <img
                                                className="d-block w-100"
                                                src="./images/slider2.png"
                                                alt="Second slide"
                                                style={{ objectFit: 'cover' }}
                                            />
                                        </Carousel.Item>
                                        <Carousel.Item>
                                            <img
                                                className="d-block w-100"
                                                src="./images/slider3.png"
                                                alt="Third slide"
                                                style={{ objectFit: 'cover' }}
                                            />
                                        </Carousel.Item>
                                    </Carousel>
                                    <div className="container mt-4">
                                        <Routes>
                                            <Route path="/" element={<Outlet />} />
                                            <Route path="/chat-room" element={<ChatRoomPage />} />
                                        </Routes>
                                    </div>
                                </Router>
                            </Col>
                        </Row>
                    </Container>
                </Col>
            </Row>

            <Row className="my-4">
                <Col>
                    <h1 className="text-center" style={{ color: 'orange', fontWeight: 'bold' }}>Welcome to Simple Chat Room</h1>
                </Col>
            </Row>
            <Row>
                <Col className="text-center">
                    <footer style={{ color: '#fff', backgroundColor: 'darkred', padding: '10px 0' }}>
                        <p>@2024 - created by FPTU</p>
                    </footer>
                </Col>
            </Row>
        </Container>
    );
}

export default App;
