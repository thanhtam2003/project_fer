export const ChatRoom = {
    "id": "room1",
    "name": "Demo Chat",
    "participants": ["user1", "user2"],
    "messages": [
        {
            "id": "message1",
            "text": "Hi Bob, how are you?",
            "senderId": "user1",
            "timestamp": "09-04-2024 09:00:00 PM"
        },
        {
            "id": "message2",
            "text": "Hey Alice, I'm good! How about you?",
            "senderId": "user2",
            "timestamp": "09-04-2024 09:01:00 PM"
        },
        {
            "id": "message3",
            "text": "I'm doing well, thanks for asking!",
            "senderId": "user1",
            "timestamp": "09-04-2024 09:02:00 PM"
        }
    ]
}